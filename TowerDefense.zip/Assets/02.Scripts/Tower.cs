using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public enum TowerState
{
    Search,
    Attack
}


public class Tower : MonoBehaviour
{
    [SerializeField] private GameObject projectilePrefab;
    [SerializeField] private Transform muzzle;

    [SerializeField] private float attackSpeed = 0.5f;
    [SerializeField] private float attackRange = 2;

    [SerializeField] TowerState towerState;

    private Transform target;
    private EnemySpawner enemySpawner;
    private WaitForSeconds speed;

    public void Setup(EnemySpawner spawner)
    {
        Debug.Log("Ÿ�� �¾� �Ϸ�");
        speed = new WaitForSeconds(attackSpeed);
        enemySpawner = spawner;

        towerState = TowerState.Search;
        ChangeState();
    }

    //Ž�� ����
    private IEnumerator Search()
    {
        Debug.Log("Ÿ�� ���� : Search");
        while(true)
        {
            float nearest = float.MaxValue;

            //���ʹ� ����Ʈ���� ���� ���� ����� ���� ã�Ƽ� Ÿ������ ����
            for (int i = 0; i < enemySpawner.EnemyList.Count; i++)
            {
                float distance = Vector2.Distance(transform.position, enemySpawner.EnemyList[i].transform.position);

                Debug.Log(distance);
                if (nearest >= distance && attackRange >= distance)
                {
                    Debug.Log("Ÿ�� ���� �Ϸ�");
                    nearest = distance;
                    target = enemySpawner.EnemyList[i].transform;
                }
            }
            if(target != null)
            {
                Debug.Log("Ÿ�� �����");
                towerState = TowerState.Attack;
                ChangeState();
            }
            yield return null;
        }
    }

    private IEnumerator Attack()
    {
        Debug.Log("Ÿ�� ���� : Attack");
        while(true)
        {
            if(target == null)
            {
                towerState = TowerState.Search;
                ChangeState();
                break;
            }
            float distance = Vector2.Distance(transform.position, target.transform.position);
            if (attackRange < distance)
            {
                target = null;
                towerState = TowerState.Search;
                ChangeState();
                break;
            }
            yield return speed;

            //����
            Fire();
        }
    }

    private void Fire()
    {
        Instantiate(projectilePrefab, muzzle.position, Quaternion.identity);
    }

    private void Update()
    {
        if(target != null)
        {
            RotateToTarget();
        }
    }

    private void ChangeState()
    {
        if (towerState == TowerState.Search)
        {
            StartCoroutine(Search());
            StopCoroutine(Attack());
        }
        if (towerState == TowerState.Attack)
        {
            StartCoroutine(Attack());
            StopCoroutine(Search());
        }
    }

    private void RotateToTarget()
    {
        transform.LookAt(target);
    }
}
