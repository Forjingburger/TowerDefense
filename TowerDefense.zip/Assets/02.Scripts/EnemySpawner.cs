using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemySpawner : MonoBehaviour
{
    //�Ѹ��� �� �� ���� �� �¾����� (1�� ����)

    [SerializeField] GameObject enemyPrefab;
    [SerializeField] Transform[] wayPoints;

    private void Start()
    {
        StartCoroutine(SpawnEnemy());
    }

    private IEnumerator SpawnEnemy()
    {
        Enemy enemy = enemyPrefab.GetComponent<Enemy>();

        while (true)
        {
            Instantiate(enemyPrefab);
            enemy.Setup(wayPoints);

            yield return new WaitForSeconds(1f);
        }
    }
}
